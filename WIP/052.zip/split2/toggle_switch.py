import tkinter as tk

class ToggleSwitch(tk.Canvas):
    def __init__(self, parent, text, variable, command=None, **kwargs):
        super().__init__(parent, width=160, height=30, bg=parent['bg'], highlightthickness=0, **kwargs)
        self.variable = variable
        self.command = command
        self.text = text

        self.rect = self.create_rectangle(5, 5, 55, 25, outline="", fill="#444")
        self.switch = self.create_oval(5, 5, 25, 25, fill="red", outline="gray")
        self.label = self.create_text(65, 15, text=text, anchor="w", fill="white", font=("Arial", 10))

        self.tag_raise(self.switch)
        self.bind("<Button-1>", self.toggle)
        self.update_switch()

    def toggle(self, event=None):
        self.variable.set(not self.variable.get())
        self.update_switch()
        if self.command:
            self.command()

    def update_switch(self):
        if self.variable.get():
            self.itemconfig(self.switch, fill="green")
            self.coords(self.switch, 35, 5, 55, 25)
        else:
            self.itemconfig(self.switch, fill="red")
            self.coords(self.switch, 5, 5, 25, 25)