# help_file_viewer.py

import os
import tkinter as tk
from tkinter import scrolledtext, messagebox

class HelpFileViewer:
    def __init__(self, parent, filename="HELP.txt"):
        """
        :param parent: Parent Tkinter widget (usually root window)
        :param filename: Name of the help file to open (default is HELP.txt in script directory)
        """
        self.parent = parent
        self.filename = filename
        self.filepath = os.path.join(os.path.dirname(os.path.abspath(__file__)), filename)

    def show(self):
        if not os.path.exists(self.filepath):
            messagebox.showerror("File Not Found", f"Could not find {self.filename} at:\n{self.filepath}")
            return

        win = tk.Toplevel(self.parent)
        win.title("Help — Scan Guard Dog")
        win.geometry("700x500")
        win.configure(bg="#1e1e1e")

        text_area = scrolledtext.ScrolledText(
            win, wrap=tk.WORD, bg="#1e1e1e", fg="#00ff00", insertbackground="white"
        )
        text_area.pack(fill='both', expand=True, padx=10, pady=10)

        try:
            with open(self.filepath, "r", encoding="utf-8") as f:
                text_area.insert(tk.END, f.read())
            text_area.configure(state='disabled')  # Make read-only
        except Exception as e:
            messagebox.showerror("Error", f"Failed to read help file:\n{e}")
