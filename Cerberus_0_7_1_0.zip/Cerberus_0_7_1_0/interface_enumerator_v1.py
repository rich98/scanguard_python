import psutil
import socket
import logging

class InterfaceEnumerator:
    def __init__(self):
        self.logger = logging.getLogger("ScanGuardDog")

    def list_interfaces_with_ips(self):
        labeled_interfaces = []
        try:
            addrs = psutil.net_if_addrs()
            for iface in psutil.net_if_addrs().keys():
                ip = None
                for addr in addrs[iface]:
                    if addr.family == socket.AF_INET:
                        ip = addr.address
                        break
                label = f"{iface} ({ip})" if ip else iface
                labeled_interfaces.append((iface, label))
        except Exception as e:
            self.logger.warning(f"Failed to retrieve interfaces: {e}")
        return labeled_interfaces