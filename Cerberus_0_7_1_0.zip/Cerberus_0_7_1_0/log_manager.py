import os
import logging
from tkinter import messagebox

logger = logging.getLogger(__name__)

class LogManager:
    def __init__(self, base_directory=None):
        if base_directory is None:
            base_directory = os.path.dirname(os.path.abspath(__file__))
        self.base_directory = base_directory

    def delete_log_files(self):
        deleted_files = []
        for filename in os.listdir(self.base_directory):
            if filename.endswith(".log") and not os.path.isdir(os.path.join(self.base_directory, filename)):
                file_path = os.path.join(self.base_directory, filename)
                try:
                    os.remove(file_path)
                    deleted_files.append(filename)
                except Exception as e:
                    logger.error(f"Failed to delete {filename}: {e}")

        if deleted_files:
            messagebox.showinfo("Log Deletion", f"Deleted {len(deleted_files)} log file(s).")
            logger.info(f"Deleted log files: {', '.join(deleted_files)}")
        else:
            messagebox.showinfo("Log Deletion", "No log files found to delete.")
            logger.info("No log files found to delete.")