import os
import tkinter as tk
from PIL import Image, ImageTk


class SplashScreen:
    def __init__(self, parent, duration=3000, image_path=None):
        self.parent = parent
        self.duration = duration
        self.image_path = image_path

        self.splash = tk.Toplevel(parent)
        self.splash.overrideredirect(True)
        self.splash.configure(bg="black")

        label = self._create_content()
        label.pack(padx=30, pady=30)

        self._center_window(self.splash)
        self.parent.withdraw()  # Hide the main window
        self.parent.after(self.duration, self._close_splash)

    def _create_content(self):
        if self.image_path and os.path.exists(self.image_path):
            try:
                image = Image.open(self.image_path)
                self.photo = ImageTk.PhotoImage(image)
                label = tk.Label(self.splash, image=self.photo, bg="black")
                label.image = self.photo  # Prevent garbage collection
                return label
            except Exception as e:
                print(f"[Splash Error] Could not load image '{self.image_path}': {e}")
        else:
            print(f"[Splash Warning] Image not found at path: {self.image_path}")

        # Fallback text label
        return tk.Label(
            self.splash,
            text="Scan Guard Dog\nStarting...",
            font=("Arial", 20, "bold"),
            fg="white",
            bg="black",
            justify="center"
        )

    def _center_window(self, window):
        window.update_idletasks()
        width = window.winfo_width()
        height = window.winfo_height()
        screen_width = window.winfo_screenwidth()
        screen_height = window.winfo_screenheight()
        x = (screen_width // 2) - (width // 2)
        y = (screen_height // 2) - (height // 2)
        window.geometry(f"{width}x{height}+{x}+{y}")

    def _close_splash(self):
        self.splash.destroy()
        self.parent.deiconify()  # Show the main app window