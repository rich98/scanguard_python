# ip_whitelistv1.0.py

import ipaddress

class IPWhitelist:
    def __init__(self, local_ipv4=None, local_ipv6=None):
        self.ip_set = set()       # Individual IPs
        self.network_set = set()  # IP networks (CIDR)
        self.local_ipv4 = local_ipv4
        self.local_ipv6 = local_ipv6
        self._initialize_defaults()

    def _initialize_defaults(self):
        default_entries = {
            "127.0.0.1",
            "::1"       
        }
        if self.local_ipv4:
            default_entries.add(self.local_ipv4)
        if self.local_ipv6:
            default_entries.add(self.local_ipv6)
        for entry in default_entries:
            self.add(entry)

    def add(self, entry):
        try:
            if "/" in entry:
                network = ipaddress.ip_network(entry, strict=False)
                self.network_set.add(network)
            else:
                ip = ipaddress.ip_address(entry)
                self.ip_set.add(ip)
        except ValueError:
            print(f"[WHITELIST] Invalid IP or network ignored: {entry}")

    def remove(self, entry):
        try:
            if "/" in entry:
                network = ipaddress.ip_network(entry, strict=False)
                self.network_set.discard(network)
            else:
                ip = ipaddress.ip_address(entry)
                self.ip_set.discard(ip)
        except ValueError:
            print(f"[WHITELIST] Invalid IP or network removal ignored: {entry}")

    def is_whitelisted(self, ip):
        try:
            ip_obj = ipaddress.ip_address(ip)
            if ip_obj in self.ip_set:
                return True
            return any(ip_obj in net for net in self.network_set)
        except ValueError:
            return False

    def load_from_file(self, path):
        try:
            with open(path, "r") as f:
                for line in f:
                    line = line.strip()
                    if line and not line.startswith("#"):
                        self.add(line)
        except Exception as e:
            print(f"[WHITELIST] Error loading from {path}: {e}")

    def export_to_file(self, path):
        try:
            with open(path, "w") as f:
                for ip in sorted(map(str, self.ip_set)):
                    f.write(ip + "\n")
                for net in sorted(map(str, self.network_set)):
                    f.write(net + "\n")
        except Exception as e:
            print(f"[WHITELIST] Error writing to {path}: {e}")