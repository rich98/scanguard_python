import tkinter as tk
from tkinter import messagebox
import threading
import time
import re


class SecureClipboardManager:
    def __init__(self, root, redact=True, auto_clear_seconds=180):
        """
        :param root: The root Tk window
        :param redact: Whether to mask sensitive IP/MACs by default
        :param auto_clear_seconds: How long before clipboard is cleared
        """
        self.root = root
        self.redact = redact
        self.auto_clear_seconds = auto_clear_seconds

    def copy(self, text, prompt=True):
        """Main method to safely copy logs to clipboard."""
        if prompt:
            confirmed = messagebox.askyesno(
                "Confirm Copy",
                "Logs may contain sensitive data.\nDo you want to continue? " \
                "Data Will auto clear in 3 minites"
            )
            if not confirmed:
                return

        if self.redact:
            text = self._redact_sensitive_info(text)

        self._copy_to_clipboard(text)
        self._clear_clipboard_delayed()

    def _copy_to_clipboard(self, text):
        self.root.clipboard_clear()
        self.root.clipboard_append(text)
        self.root.update()

    def _clear_clipboard_delayed(self):
        def clear():
            time.sleep(self.auto_clear_seconds)
            try:
                self.root.clipboard_clear()
            except Exception:
                pass  # fail silently

        threading.Thread(target=clear, daemon=True).start()

    def _redact_sensitive_info(self, text):
        text = re.sub(r'\b(?:\d{1,3}\.){3}\d{1,3}\b', '[REDACTED_IP]', text)
        text = re.sub(r'\b(?:[0-9a-fA-F]{2}:){5}[0-9a-fA-F]{2}\b', '[REDACTED_MAC]', text)
        return text
