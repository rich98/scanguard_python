import threading
import time
import tkinter as tk
from tkinter import messagebox, ttk
import configparser
import os

class ScheduledPortScanner:
    def __init__(self, root, scan_callback):
        """
        :param root: Tkinter root window (for GUI thread safety)
        :param scan_callback: Function to call to perform a port scan
        """
        self.root = root
        self.scan_callback = scan_callback
        self.interval_minutes = None
        self.scan_thread = None
        self.stop_event = threading.Event()

    def open_schedule_window(self):
        import tkinter as tk
        from tkinter import ttk, messagebox
        import datetime

        self.window = tk.Toplevel(self.root)
        self.window.title("Schedule Scan")
        self.window.geometry("300x200")
        self.window.configure(bg="#2e2e2e")

        # Time input
        tk.Label(self.window, text="Time (HH:MM)", bg="#2e2e2e", fg="white").pack(pady=5)
        time_entry = tk.Entry(self.window)
        time_entry.pack()

        # Port range input
        tk.Label(self.window, text="Port Range (e.g., 20-80 or 443)", bg="#2e2e2e", fg="white").pack(pady=5)
        port_entry = tk.Entry(self.window)
        port_entry.pack()

        # Inner function to save the schedule
        def schedule():
            time_str = time_entry.get()
            port_str = port_entry.get()
            try:
                datetime.datetime.strptime(time_str, "%H:%M")
                self.save_schedule(time_str, port_str)
                self.load_schedule()
                messagebox.showinfo("Scan Scheduled", f"Scheduled for {time_str} on ports {port_str}.")
                self.window.destroy()
            except ValueError:
                messagebox.showerror("Invalid Input", "Time must be in HH:MM format.")

        # This is the Save button
        ttk.Button(self.window, text="Save", command=schedule).pack(pady=10)

        # This is the Cancel Scheduled Scan button
        ttk.Button(self.window, text="Cancel Scheduled Scan", command=self.cancel_scheduled_scan).pack(pady=5)


    def set_schedule(self, minutes):
        self.interval_minutes = minutes
        if self.scan_thread and self.scan_thread.is_alive():
            self.stop_event.set()
            self.scan_thread.join()
            self.stop_event.clear()

        self.scan_thread = threading.Thread(target=self._scan_loop, daemon=True)
        self.scan_thread.start()

    def _scan_loop(self):
        while not self.stop_event.is_set():
            time.sleep(self.interval_minutes * 60)
            if not self.stop_event.is_set():
                self.root.after(0, self.scan_callback)

    def stop(self):
        if self.scan_thread and self.scan_thread.is_alive():
            self.stop_event.set()
            self.scan_thread.join()

    def cancel_scheduled_scan(self):
        if hasattr(self, 'scheduled_task') and self.scheduled_task:
            self.root.after_cancel(self.scheduled_task)
            self.scheduled_task = None
            messagebox.showinfo("Cancelled", "Scheduled scan has been cancelled.")

    def save_schedule(self, time_str, port_range):
        config_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'config.ini')
        config = configparser.ConfigParser()
        config.read(config_path)

        if 'scan_schedule' not in config:
            config.add_section('scan_schedule')

        config.set('scan_schedule', 'time', time_str)
        config.set('scan_schedule', 'port_range', port_range)

        with open(config_path, 'w') as configfile:
            config.write(configfile)

    def load_schedule(self):
        import configparser
        import datetime

        config_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'config.ini')
        config = configparser.ConfigParser()
        config.read(config_path)

        if config.has_section('scan_schedule'):
            time_str = config['scan_schedule'].get('time')
            port_str = config['scan_schedule'].get('port_range')

            if time_str:
                now = datetime.datetime.now()
                sched_time = datetime.datetime.strptime(time_str, "%H:%M").replace(
                    year=now.year, month=now.month, day=now.day)

                if sched_time < now:
                    sched_time += datetime.timedelta(days=1)

                delay_ms = int((sched_time - now).total_seconds() * 1000)

                # Store this so we can cancel later
                self.scheduled_task = self.root.after(delay_ms, lambda: self.run_scheduled_scan(port_str))
    
    def run_scheduled_scan(self, port_range_str):
        if "-" in port_range_str:
            start, end = map(int, port_range_str.split("-"))
        else:
            start = end = int(port_range_str)

        self.scan_callback((start, end))  # Expecting a callable that takes (start, end)