class SuspiciousPortDetector:
    SUSPICIOUS_PORTS = {
        23: "Telnet",
        445: "SMB",
        3389: "RDP",
        135: "DCOM",
        1900: "SSDP",
        69: "TFTP",
        1433: "MSSQL",
        1521: "Oracle DB",
        21: "FTP",
        2222: "Alternate SSH",
        31337: "BackOrifice (classic malware)"
    }

    def __init__(self, log_function, should_log_function):
        """
        :param log_function: A function to call with suspicious port logs (e.g., NetworkMonitor.log_abnormality).
        :param should_log_function: A function to check alert suppression timing (e.g., NetworkMonitor._should_log).
        """
        self.log_abnormality = log_function
        self._should_log = should_log_function

    def check_ports(self, src_ip, unique_ports, protocol="TCP", hostname=None, interface="all"):
        suspicious = [p for p in unique_ports if p in self.SUSPICIOUS_PORTS]
        if not suspicious:
            return

        host_info = f"{src_ip} ({hostname})" if hostname else src_ip
        for port in suspicious:
            service = self.SUSPICIOUS_PORTS[port]
            alert_key = f"suspicious_{protocol.lower()}_{src_ip}_{port}"
            if self._should_log(alert_key):
                msg = f"Suspicious {protocol} port {port} ({service}) probed by {host_info}"
                self.log_abnormality("TCP_SCAN" if protocol == "TCP" else "UDP_SCAN", msg, level="warning")