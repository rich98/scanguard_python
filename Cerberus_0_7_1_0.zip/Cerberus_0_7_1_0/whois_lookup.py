import whois
from ipwhois import IPWhois

class WhoisLookup:
    def __init__(self, root, simpledialog, scrolledtext, tk, threading, thread_safe):
        self.root = root
        self.simpledialog = simpledialog
        self.scrolledtext = scrolledtext
        self.tk = tk
        self.threading = threading
        self.thread_safe = thread_safe

    def open_whois_console(self):
        ip_or_domain = self.simpledialog.askstring("Whois Lookup", "Enter IP address or domain:")
        if not ip_or_domain:
            return

        whois_window = self.tk.Toplevel(self.root)
        whois_window.title(f"Whois Results for {ip_or_domain}")
        whois_window.geometry("700x500")
        whois_window.configure(bg="#1e1e1e")

        text_area = self.scrolledtext.ScrolledText(whois_window, wrap=self.tk.WORD, bg="#1e1e1e", fg="#00ff00", insertbackground="white")
        text_area.pack(fill='both', expand=True, padx=10, pady=10)
        text_area.insert(self.tk.END, f"Looking up {ip_or_domain}...\n")
        text_area.configure(state='disabled')

        def run_combined_whois():
            output = ""
            try:
                result = whois.whois(ip_or_domain)
                output = "\n".join(f"{k}: {v}" for k, v in result.items() if v)
            except Exception as domain_e:
                try:
                    ip_obj = IPWhois(ip_or_domain)
                    res = ip_obj.lookup_rdap()
                    output = "\n".join(f"{k}: {v}" for k, v in res.items() if v)
                except Exception as ip_e:
                    output = f"Domain WHOIS error: {domain_e}\nIP WHOIS error: {ip_e}"

            def display_result():
                text_area.configure(state='normal')
                text_area.delete("1.0", self.tk.END)
                text_area.insert(self.tk.END, output)
                text_area.configure(state='disabled')

            self.root.after(0, display_result)

        self.threading.Thread(target=self.thread_safe(run_combined_whois), daemon=True).start()