import os
import tkinter as tk
from PIL import Image, ImageTk


class BackgroundImageManager:
    def __init__(self, root: tk.Tk, image_filename: str, dark_mode_enabled: callable):
        """
        Manages a background image for dark mode.

        :param root: The Tkinter root window.
        :param image_filename: Image file in the same directory as the script.
        :param dark_mode_enabled: A callable that returns True if dark mode is active.
        """
        self.root = root
        self.image_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), image_filename)
        self.dark_mode_enabled = dark_mode_enabled

        self.background_label = None
        self.tk_image = None

        try:
            self.resample_method = Image.Resampling.LANCZOS  # Pillow >= 10
        except AttributeError:
            self.resample_method = Image.ANTIALIAS  # Pillow < 10

    def apply_background(self):
        """
        Applies or removes the background image depending on dark mode state.
        """
        if self.dark_mode_enabled():
            self._set_background()
        else:
            self._remove_background()

    def _set_background(self):
        try:
            image = Image.open(self.image_path)
            image = image.resize((self.root.winfo_width(), self.root.winfo_height()), self.resample_method)
            self.tk_image = ImageTk.PhotoImage(image)

            if self.background_label is None:
                self.background_label = tk.Label(self.root, image=self.tk_image, borderwidth=0)
                self.background_label.place(x=0, y=0, relwidth=1, relheight=1)
                self.background_label.lower()
            else:
                self.background_label.configure(image=self.tk_image)
        except Exception as e:
            print(f"[BackgroundImageManager] Failed to load background: {e}")

    def _remove_background(self):
        if self.background_label:
            self.background_label.destroy()
            self.background_label = None

